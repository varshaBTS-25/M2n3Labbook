package com.cg.m14;

public interface EmployeeService {
public Employee getDetails(int empId);
}
